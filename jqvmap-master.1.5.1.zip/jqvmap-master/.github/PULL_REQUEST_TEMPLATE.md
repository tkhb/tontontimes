#### What does this PR do ?

_type_response_here_

#### How should this be tested ?

_type_response_here_

#### What are the relevant issues ?

_github_issue_numbers_this_addresses_

#### This Pull Request includes:

- [ ] Bug Fix with passing `npm test`
- [ ] New Feature with passing `npm test`
- [ ] Code Improvement with passing `npm test`
- [ ] Updated Documentation
- [ ] New Map File & Example HTML

#### What gif best describes how you feel about this work ?

_drag_and_drop_asset_here_
